﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ExcelTest
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ReadExcel();
            ReadDatagriview();
        }

        private void ReadExcel()
        {
            OleDbConnection conn = null;
            try
            {
                DataSet ds = new DataSet();
                OpenFileDialog openFile = new OpenFileDialog();
                openFile.Filter = ("Excel 文件(*.xls)|*.xls");
                if (openFile.ShowDialog() == DialogResult.OK)
                {
                    string filename = openFile.FileName;
                    string strConn = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filename + ";Extended Properties=\"Excel 8.0;HDR=YES;IMEX=1\"";
                    conn = new OleDbConnection(strConn);
                    string strExcel = "";
                    OleDbDataAdapter myCommand = null;

                    strExcel = "select * from [sheet1$]";
                    conn.Open();
                    myCommand = new OleDbDataAdapter(strExcel, strConn);
                    myCommand.Fill(ds, "dtSource");
                    mySource.DataSource = ds;
                    mySource.DataMember = "dtSource";
                    //dgvExcelInfo.DataSource = mySource;
                }
            }
            catch (Exception ex)
            {
                //ds = null;
                MessageBox.Show("查看出错：" + ex.ToString(), "错误信息");
            }
            finally
            {
                if (conn != null)
                {
                    conn.Close();
                }
            }
        }

        string txt = "sample.txt";
        private void ReadDatagriview()
        {
            FileInfo myFile = new FileInfo(txt);
            StreamWriter sW = myFile.CreateText();
            var rows = mySource.RowCount;
            var count = mySource.ColumnCount;
            for (int i = 0; i < rows; i++)
            {
                StringBuilder strb = new StringBuilder();
                for (int j = 0; j < count; j++)
                {
                    var content = mySource.Rows[i].Cells[j];
                    strb.Append(content.Value);
                    if(j!= count-1)
                    {
                        strb.Append("\t");
                    }
                }
                //Console.WriteLine(strb.ToString());
                sW.WriteLine(strb.ToString());
            }
            sW.Close();
        }
    }
}
